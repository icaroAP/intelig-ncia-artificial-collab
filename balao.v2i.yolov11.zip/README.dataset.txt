# balao > 2024-12-01 8:30pm
https://universe.roboflow.com/icaro-gomes/balao-0pudr

Provided by a Roboflow user
License: CC BY 4.0

